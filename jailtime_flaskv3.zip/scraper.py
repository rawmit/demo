import time
import requests
import bs4
import sqlite3

datas = sqlite3.connect('data/all_data.db')
datas_cur = datas.cursor()
datas_cur.executescript("""CREATE TABLE IF NOT EXISTS monthly_datas_table(userid INT , nickname TEXT, monthly_time INT);
CREATE TABLE IF NOT EXISTS daily_datas_table(userid INT, nickname TEXT, daily_time INT);
CREATE TABLE IF NOT EXISTS now_datas_table(userid INT, nickname TEXT, now_time INT);
CREATE TABLE IF NOT EXISTS server_status(id INT, players_slot INT, map_name TEXT, online TEXT);
INSERT INTO server_status(id, players_slot, map_name, online) VALUES(1, 0, 'UNKNOWN_MAP', 'UNKNOWN_ONLINE_STATUS');""")
datas.commit()

admins_data = sqlite3.connect('data/admins_data.db')
admins_data_cur = admins_data.cursor()
admins_data_cur.execute("""CREATE TABLE IF NOT EXISTS datas(userid INT, nickname TEXT, monthly_time INT DEFAULT 0, daily_time INT DEFAULT 0);""")
admins_data.commit()
admins_list_for_save_in_sql = [(0, '[supervisor] palycity'), (1, '[power-admin] e~sigari'), (2, '[power-admin] alisorroww'), (3, '[power-admin] suctory'), (4, '[senior-admin] sosmar')\
    ,(5, '[senior-admin] de/n/di'), (6, '[admin] nimpiq'), (7, '[helper] ghost.bm'), (8, '[helper] kc'), (9, '[helper] |s|herlock |h|olmes')\
        , (10, '[helper] mewz') ]

admins_data_cur.executemany("INSERT INTO datas(userid, nickname) VALUES(?, ?)", admins_list_for_save_in_sql)
admins_data.commit()

admins_list = ['[supervisor] palycity', '[power-admin] e~sigari', '[power-admin] alisorroww', '[power-admin] suctory', '[senior-admin] sosmar',\
     '[senior-admin] de/n/di', '[admin] nimpiq', '[helper] ghost.bm', '[helper] kc', '[helper] |s|herlock |h|olmes', '[helper] mewz']
last_refresh_time_list = []
save_names_list_24 = []
save_times_list_24 = []
read_00_daily = True
run = True
while run:
        page = requests.get('http://5.63.10.198/Cs16_AsiaGame/?s=12')
        soup = bs4.BeautifulSoup(page.content, features='html.parser')
        details = soup.findAll("td")

        filtered_details = []
        for detail in details:
            dtstring = str(detail.string).strip()
            lower_dtstring = dtstring.lower()
            if dtstring.find('Banner') != -1 or dtstring.find('None') != -1 or dtstring.find('Codes') != -1 or dtstring.find('halflife') != -1 or dtstring.find('GAME LINK') != -1 \
                or dtstring.find('cstrike') != -1:
                pass
            else:
                filtered_details.append(lower_dtstring)

        # Get Server Online Status [online_status]
        online_stts = filtered_details[0]
        online_status = online_stts.replace(" ","")
        if online_status == 'on':
            datas_cur.execute("UPDATE server_status SET online = 'ON'")
            datas.commit()
        else:
            datas_cur.execute("UPDATE server_status SET online = 'OFF'")
            datas.commit()

        # Get Server Domain Name [server_address]
        server_addr = filtered_details[1]
        server_address = server_addr.replace(" ","")

        # Get Server PORT [port]
        prt = filtered_details[2]
        port = prt.replace(" ","")

        # Get MapName [mapname]
        mapnm = filtered_details[4]
        mapname = mapnm.replace(" ","")
        datas_cur.execute(f"UPDATE server_status SET map_name = '{mapname}'")
        datas.commit()
        # Get Number Of Players [players_slot]
        players_slt = filtered_details[5]
        players_slot = players_slt.replace(" ","")
        players_slot = int(players_slot[:-3])
        datas_cur.execute(f"UPDATE server_status SET players_slot = {players_slot}")
        datas.commit()
        server_status_message = f'Server Status : {online_status} \nOnlines: {players_slot}\nServer Address: {server_address}:{port}\nMapName: {mapname}\n'

        if players_slot == 0:
            print('Slot 0/32')
            pass
                
        else:
                
            del filtered_details[:4]
            del filtered_details[:2]

            userid = 0
            t=2
            p=0
            filtered_details_len = len(filtered_details)
            while p<filtered_details_len:
                t1 = filtered_details[t]
                minute_time = int(t1[3:-3])
                p_name = filtered_details[p]
                datas_cur.executescript(f"INSERT INTO now_datas_table(userid, nickname, now_time) VALUES({userid}, '{p_name}', {minute_time});")
                datas.commit()
                if p_name not in save_names_list_24:
                    datas_cur.executescript(f"INSERT INTO daily_datas_table(userid, nickname, daily_time) VALUES({userid}, '{p_name}',{minute_time});")
                    datas.commit()
                    save_names_list_24.append(filtered_details[p])
                    save_times_list_24.append(minute_time)
                    last_refresh_time_list.append(minute_time)
                else:
                    p_name = filtered_details[p]
                    p_time = int(minute_time)
                    p_name_number = save_names_list_24.index(p_name)
                    saved_time = last_refresh_time_list[p_name_number]
                    if saved_time == p_time:
                        pass
                    else:
                        player_time_in_save_list = save_times_list_24[p_name_number]
                        if p_time>saved_time:
                            result1 = p_time-saved_time
                            result_time_for_save = result1+player_time_in_save_list
                            datas_cur.executescript(f"UPDATE daily_datas_table SET daily_time = {result_time_for_save} WHERE nickname like '{p_name}'")
                            datas.commit()
                            save_times_list_24[p_name_number] = result_time_for_save
                            last_refresh_time_list[p_name_number] = p_time
                        elif p_time<saved_time:
                            last_refresh_time_list[p_name_number] = p_time
                            result_time_for_save = p_time+player_time_in_save_list
                            datas_cur.executescript(f"UPDATE daily_datas_table SET daily_time = {result_time_for_save} WHERE nickname like '{p_name}'")
                            datas.commit()
                            save_times_list_24[p_name_number] = result_time_for_save        
                userid=userid+1
                p=p+3
                t=t+3
                for name in save_names_list_24:
                    if name not in admins_list:
                        pass
                    else:
                        name_number = save_names_list_24.index(name)
                        player_time_in_save_list = save_times_list_24[name_number]
                        admins_data_cur.executescript(f"UPDATE datas SET daily_time = {player_time_in_save_list} WHERE nickname like '{name}'")
                        admins_data.commit()
                            
                            
            # Get Players Kills [kills]
            kills = []

            p=1
            while p<filtered_details_len:
                kills.append(filtered_details[p])
                p=p+3

            # Get Players Time Online [players_time]
            players_time = []

            p=2
            while p<filtered_details_len:
                players_time.append(filtered_details[p])
                p=p+3
        
        if int(time.strftime('%m')) <= 6:
            if time.strftime('%d') == '31':
                read_01_monthly = True
        elif int(time.strftime('%m')) >= 7:
            if time.strftime('%d') == '30':
                read_01_monthly = True
        if time.strftime('%H') == '00':
            if read_00_daily:
                print('Time To RESET!')
                datas_cur.execute("SELECT userid, nickname, daily_time FROM daily_datas_table")
                all_daily_times_for_save_in_monthly_table = datas_cur.fetchall()
                datas_cur.executemany("INSERT INTO monthly_datas_table(userid, nickname, monthly_time) VALUES(?, ?, ?)", all_daily_times_for_save_in_monthly_table)
                datas_cur.executescript("DELETE FROM daily_datas_table")
                datas.commit()
                admins_data_cur.execute("SELECT userid,nickname,monthly_time, daily_time FROM datas")
                admins_all_daily_time_for_save_in_monthly_field = admins_data_cur.fetchall()
                for admin_detail in admins_all_daily_time_for_save_in_monthly_field:
                    admin_nickname = admin_detail[1]
                    monthly_time_in_admins_database = admin_detail[2]
                    daily_time_in_admins_database = admin_detail[3]
                    result_for_save_to_database = monthly_time_in_admins_database + daily_time_in_admins_database
                    admins_data_cur.executescript(f"UPDATE datas SET daily_time = 0, monthly_time = {result_for_save_to_database} WHERE nickname LIKE '{admin_nickname}'")
                    admins_data.commit()
                last_refresh_time_list = []
                save_names_list_24 = []
                save_times_list_24 = []
                read_00_daily = False
            else:
                pass
        if time.strftime('%H') == '01':
            read_00_daily = True
        else:
            pass
        if time.strftime('%d') == '01':
            if read_01_monthly:
                print('Monthly RESET TIME NOW!!')
                admins_data_cur.executescript("DELETE FROM datas WHERE monthly_time")
                admins_data.commit()
                datas_cur.executescript("DELETE FROM monthly_datas_table")
                datas.commit()
                read_01_monthly = False
            else:
                pass
        else: 
            pass
        t = time.strftime('%S')
        print(f'{t}\t5s to refresh..')
        time.sleep(5)
        datas_cur.executescript("DELETE FROM now_datas_table")
        datas.commit()