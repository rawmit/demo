from flask import Flask, render_template, request
import sqlite3

app = Flask(__name__)


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'GET':
        return render_template('index.html')
    elif request.method == 'POST':
        password = request.form['password']
        if password == 'raw':
            return panel()
        else:
            return 'Invalid Password!'
def panel():
    # All Admins Details (userid, nickname, monthly time, daily time)
    admins_userid = []
    admins_nickname = []
    admins_monthly_time = []
    admins_daily_time = []

    # All Players Monthly Details (userid, nickname, time)
    all_players_monthly_userid = []
    all_players_monthly_nickname = []
    all_players_monthly_time = []

    # All Players Daily Details (userid, nickname, time)
    all_players_daily_userid = []
    all_players_daily_nickname = []
    all_players_daily_time = []

    # All Players Now Details (userid, nickname, time)
    all_players_now_userid = []
    all_players_now_nickname = []
    all_players_now_time = []

    # Server Status Now (players slot, map name, online/offline status)
    server_status_now = []
    datas = sqlite3.connect('data/all_data.db')
    datas_cur = datas.cursor()

    admins_data = sqlite3.connect('data/admins_data.db')
    admins_data_cur = admins_data.cursor()
    
    admins_data_cur.execute("SELECT userid, nickname, monthly_time, daily_time FROM datas")
    admins_details = admins_data_cur.fetchall()
    for admin_detail in admins_details:
        admins_userid.append(admin_detail[0])
        admins_nickname.append(admin_detail[1])
        admins_monthly_time.append(admin_detail[2])
        admins_daily_time.append(admin_detail[3])

    datas_cur.execute("SELECT userid, nickname, monthly_time  FROM monthly_datas_table")
    monthly_table = datas_cur.fetchall()
    for detail in monthly_table:
        all_players_monthly_userid.append(detail[0])
        all_players_monthly_nickname.append(detail[1])
        all_players_monthly_time.append(detail[2])

    datas_cur.execute("SELECT userid, nickname, daily_time  FROM daily_datas_table")
    daily_table = datas_cur.fetchall()
    for detail in daily_table:
        all_players_daily_userid.append(detail[0])
        all_players_daily_nickname.append(detail[1])
        all_players_daily_time.append(detail[2])

    datas_cur.execute("SELECT userid, nickname, now_time  FROM now_datas_table")
    now_table = datas_cur.fetchall()
    for detail in now_table:
        all_players_now_userid.append(detail[0])
        all_players_now_nickname.append(detail[1])
        all_players_now_time.append(detail[2])

    datas_cur.execute("SELECT  players_slot, map_name, online  FROM server_status")
    server_status = datas_cur.fetchall()
    for detail in server_status:
        server_status_now.append(detail[0])
        server_status_now.append(detail[1])
        server_status_now.append(detail[2])

    return render_template('panel.html', admins_userid=admins_userid, admins_nickname=admins_nickname,admins_monthly_time=admins_monthly_time\
        , admins_daily_time=admins_daily_time, all_players_monthly_userid=all_players_monthly_userid, all_players_monthly_nickname=all_players_monthly_nickname\
            , all_players_monthly_time=all_players_monthly_time, all_players_daily_userid=all_players_daily_userid, all_players_daily_nickname=all_players_daily_nickname\
                , all_players_daily_time=all_players_daily_time, all_players_now_userid=all_players_now_userid, all_players_now_nickname=all_players_now_nickname\
                    ,all_players_now_time=all_players_now_time, server_status_now=server_status_now)

if __name__ == '__main__':
    app.run(debug=True)
    